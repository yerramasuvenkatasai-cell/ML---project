# CricketIQ — Cricket Match Result Prediction Website

A Flask website for the academic project **Multi-Class Match Result Prediction Using Multinomial Logistic Regression**.

## Main domain
Machine Learning → Supervised Learning → Multi-Class Classification, applied to cricket sports analytics.

## Features
- Cricket match prediction form
- Win / Loss / No Result probabilities
- Dataset overview and outcome distribution
- Test-split accuracy, weighted precision, recall, F1-score
- Confusion matrix
- Basic data-quality checks
- Dataset included in `data/`

## Requirements
- Python 3.10 or newer recommended
- Internet connection for the first dependency installation
- No API key or database is required for this local demo

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `Cricket_Match_Prediction_Website` folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment (recommended):

   ```bash
   py -m venv .venv
   .venv\Scripts\activate
   ```

5. Install libraries:

   ```bash
   python -m pip install -r requirements.txt
   ```

6. Start the website:

   ```bash
   python app.py
   ```

7. Open this address in your browser:

   http://127.0.0.1:5000

## Run on macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```
Then visit `http://127.0.0.1:5000`.

## Important modeling note
The uploaded dataset has 1,200 rows and 17 original columns. The current model uses venue, team names, toss result/decision, first- and second-innings runs and wickets, and recent-form score. Runs and wickets are generally known only during or after a match, so this is a dataset-based match-result classification demo rather than a strict pre-match forecasting model. For a fair pre-match prediction, remove post-match features and retrain using only information available before the first ball.

Model evaluation uses a stratified 80/20 train/test split with a fixed random seed. The reported metrics are calculated from this dataset and should not be treated as evidence of real-world accuracy on future matches. The model is trained when the Flask app starts.

## Project structure
```text
Cricket_Match_Prediction_Website/
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── Cricket_Match_Dataset.xlsx
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Tech stack
Python, Flask, Pandas, NumPy, scikit-learn, HTML, CSS, and Excel dataset.

## Disclaimer
Predictions are estimates, not guarantees. This academic demo does not fetch live match data from a Cricket API.
