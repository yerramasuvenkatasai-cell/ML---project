
from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
from flask import Flask, render_template, request
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "Cricket_Match_Dataset.xlsx"

app = Flask(__name__)

TARGET = "Match Result"
CATEGORICAL = ["Venue", "Team 1", "Team 2", "Toss Result", "Toss Decision"]
NUMERIC = [
    "First Innings Runs", "Second Innings Runs",
    "First Innings Wickets", "Second Innings Wickets",
    "Recent Form Score"
]
FEATURES = CATEGORICAL + NUMERIC
OUTCOMES = ["Win", "Loss", "No Result"]

def load_data():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found at {DATA_PATH}. Put Cricket_Match_Dataset.xlsx inside the data folder."
        )
    data = pd.read_excel(DATA_PATH)
    required = FEATURES + [TARGET]
    missing = [c for c in required if c not in data.columns]
    if missing:
        raise ValueError("Dataset is missing required columns: " + ", ".join(missing))
    data = data[required].copy()
    data[TARGET] = data[TARGET].astype(str).str.strip()
    data = data[data[TARGET].isin(OUTCOMES)].dropna(subset=[TARGET])
    for col in CATEGORICAL:
        data[col] = data[col].fillna("Unknown").astype(str)
    for col in NUMERIC:
        data[col] = pd.to_numeric(data[col], errors="coerce")
        data[col] = data[col].fillna(data[col].median())
    return data

DATA = load_data()
X = DATA[FEATURES]
y = DATA[TARGET]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)
preprocessor = ColumnTransformer(
    transformers=[
        ("categorical", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))
        ]), CATEGORICAL),
        ("numeric", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scale", StandardScaler())
        ]), NUMERIC)
    ]
)
model = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", LogisticRegression(max_iter=2000, solver="lbfgs"))
])
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    model.fit(X_train, y_train)
preds = model.predict(X_test)
accuracy = accuracy_score(y_test, preds)
precision = precision_score(y_test, preds, average="weighted", zero_division=0)
recall = recall_score(y_test, preds, average="weighted", zero_division=0)
f1 = f1_score(y_test, preds, average="weighted", zero_division=0)
labels = sorted(set(y_test) | set(preds))
cm = confusion_matrix(y_test, preds, labels=labels)
report = classification_report(y_test, preds, labels=labels, output_dict=True, zero_division=0)

def options_for(col):
    return sorted(DATA[col].dropna().astype(str).unique().tolist())

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error = None
    defaults = {
        "Venue": options_for("Venue")[0] if options_for("Venue") else "",
        "Team 1": options_for("Team 1")[0] if options_for("Team 1") else "",
        "Team 2": options_for("Team 2")[1] if len(options_for("Team 2")) > 1 else (options_for("Team 2")[0] if options_for("Team 2") else ""),
        "Toss Result": "Won Toss",
        "Toss Decision": "Bat",
        "First Innings Runs": "160",
        "Second Innings Runs": "150",
        "First Innings Wickets": "6",
        "Second Innings Wickets": "7",
        "Recent Form Score": "6.0",
    }
    if request.method == "POST":
        try:
            values = {
                "Venue": request.form.get("Venue", "").strip(),
                "Team 1": request.form.get("Team 1", "").strip(),
                "Team 2": request.form.get("Team 2", "").strip(),
                "Toss Result": request.form.get("Toss Result", "").strip(),
                "Toss Decision": request.form.get("Toss Decision", "").strip(),
                "First Innings Runs": float(request.form.get("First Innings Runs", "160")),
                "Second Innings Runs": float(request.form.get("Second Innings Runs", "150")),
                "First Innings Wickets": float(request.form.get("First Innings Wickets", "6")),
                "Second Innings Wickets": float(request.form.get("Second Innings Wickets", "7")),
                "Recent Form Score": float(request.form.get("Recent Form Score", "6.0")),
            }
            if values["Team 1"] == values["Team 2"]:
                raise ValueError("Please select two different teams.")
            for col in NUMERIC:
                if not np.isfinite(values[col]):
                    raise ValueError(f"{col} must be a valid number.")
            if not 0 <= values["First Innings Wickets"] <= 10 or not 0 <= values["Second Innings Wickets"] <= 10:
                raise ValueError("Wickets must be between 0 and 10.")
            if values["First Innings Runs"] < 0 or values["Second Innings Runs"] < 0:
                raise ValueError("Runs cannot be negative.")
            if not 0 <= values["Recent Form Score"] <= 10:
                raise ValueError("Recent Form Score must be between 0 and 10.")
            sample = pd.DataFrame([{k: values[k] for k in FEATURES}])
            predicted = model.predict(sample)[0]
            probs = model.predict_proba(sample)[0]
            probability = {label: round(float(prob) * 100, 1) for label, prob in zip(model.classes_, probs)}
            result = {"label": predicted, "probability": probability, "confidence": max(probability.values()), "values": values}
            defaults = {k: str(v) for k, v in values.items()}
        except Exception as exc:
            error = str(exc)
    class_counts = DATA[TARGET].value_counts().reindex(OUTCOMES, fill_value=0).to_dict()
    summary = {
        "rows": int(DATA.shape[0]),
        "columns": int(pd.read_excel(DATA_PATH).shape[1]),
        "accuracy": round(accuracy * 100, 2),
        "precision": round(precision * 100, 2),
        "recall": round(recall * 100, 2),
        "f1": round(f1 * 100, 2),
        "missing": int(pd.read_excel(DATA_PATH).isna().sum().sum()),
        "duplicates": int(pd.read_excel(DATA_PATH).duplicated().sum()),
        "counts": class_counts,
        "labels": labels,
        "matrix": cm.tolist(),
        "report": {k: {m: round(float(v.get(m, 0)), 3) for m in ["precision", "recall", "f1-score", "support"]} for k, v in report.items() if isinstance(v, dict) and k in labels},
        "teams": options_for("Team 1"),
        "venues": options_for("Venue")
    }
    return render_template("index.html", result=result, error=error, defaults=defaults, summary=summary,
                           venues=options_for("Venue"), teams=options_for("Team 1"))

@app.route("/health")
def health():
    return {"status": "ok", "dataset_rows": int(len(DATA)), "model": "Multinomial Logistic Regression"}

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
